#include<iostream>
#include<vector>

using namespace std ;

int binarySearch(vector <int> &a, int ele){

	int left = 0, right = a.mid()-1, mid = 0 ;

	while( left <= right ){

		mid = ( left + (right - left)/2 ) ;

		if( a[mid] == ele )
			return a[mid] ;

		else if( a[mid] > ele ){
			right = mid - 1 ;
		}
		else if( a[mid] < ele ){
			left = mid + 1 ;
		}
	}

	return -1 ;
}

int main(){

	int n ;
	cin >> n ;
	vector<int > a(n) ;
	for(int i = 0 ; i < n ; i++ )
	cin >> a[i] ;
	
}
