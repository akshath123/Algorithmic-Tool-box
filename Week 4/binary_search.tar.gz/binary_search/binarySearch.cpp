#include<iostream>
#include<vector>

using std::vector ;
using std::cout ;
using std::cin ;

int binarySearch(const vector<int> &a, int x){

	int left = 0, right = a.size()-1, mid = 0 ;

	while( left <= right ){
//		cout << "Before: element: " << x << " mid: " << mid << " left: " << left << " right: " << right << "\n" ;
		mid = ( left + (right-left)/2 ) ;

		if( x == a[mid] )
			return mid ;
		else if( x < a[mid] )
			right = mid - 1;
		else if( x > a[mid] )
			left = mid + 1 ;
//		cout << "After: element: " << x << " mid: " << mid << " left: " << left << " right: " << right << "\n" ;
	}

	return -1 ;
}

int main(){

	int n, k ;

	cin >> n ;
	vector<int> arr(n) ;

	for(size_t i = 0 ; i < arr.size() ; i++ )
	cin >> arr[i] ;

	cin >> k ;
	vector<int> eleSearch(k) ;

	for(size_t i = 0 ; i < eleSearch.size() ; i++ )
	cin >> eleSearch[i] ;

	for(size_t i = 0 ; i < eleSearch.size() ; i++ ){
		cout << binarySearch(arr, eleSearch[i]) << " " ;
	}

	return 0 ;
}
